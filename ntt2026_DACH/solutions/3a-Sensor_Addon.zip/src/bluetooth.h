#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

#include <stdint.h>

int bluetooth_init(void);
int bluetooth_set_battery_level_and_notify(uint8_t level);

#endif