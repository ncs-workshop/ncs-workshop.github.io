#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/sys/printk.h>
#include <zephyr/sys/util.h>

#include "bluetooth.h"

static const struct bt_data advertising_data[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
};

static const struct bt_data scan_response_data[] = {
	BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
		 sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

static void connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		return;
	}

	err = bt_conn_set_security(conn, BT_SECURITY_L2);
	if (err) {
		printk("Failed to request LE Secure Connections\n");
	}
}

static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	ARG_UNUSED(conn);

	if (err || level < BT_SECURITY_L2) {
		printk("Bluetooth link security failed\n");
		return;
	}

	printk("Bluetooth link secured with LE Secure Connections\n");
}

BT_CONN_CB_DEFINE(bluetooth_connection_callbacks) = {
	.connected = connected,
	.security_changed = security_changed,
};

static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	ARG_UNUSED(conn);

	if (bonded) {
		printk("Bluetooth pairing completed with unexpected bonding\n");
		return;
	}

	printk("Bluetooth pairing completed without bonding\n");
}

static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	int err;

	ARG_UNUSED(reason);
	printk("Bluetooth pairing failed\n");

	err = bt_conn_disconnect(conn, BT_HCI_ERR_AUTH_FAIL);
	if (err) {
		printk("Failed to disconnect after Bluetooth pairing failure\n");
	}
}

static struct bt_conn_auth_info_cb bluetooth_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed,
};

int bluetooth_init(void)
{
	int err = bt_enable(NULL);

	if (err) {
		printk("Bluetooth initialization failed (err %d)\n", err);
		return err;
	}

	printk("Bluetooth initialized\n");
	bt_set_bondable(false);

	err = bt_conn_auth_info_cb_register(&bluetooth_auth_info_callbacks);
	if (err) {
		printk("Failed to register Bluetooth security callbacks\n");
		return err;
	}

	err = bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, advertising_data,
			      ARRAY_SIZE(advertising_data), scan_response_data,
			      ARRAY_SIZE(scan_response_data));
	if (err) {
		printk("Bluetooth advertising failed to start (err %d)\n", err);
		return err;
	}

	printk("Bluetooth advertising as %s\n", CONFIG_BT_DEVICE_NAME);
	return 0;
}

int bluetooth_set_battery_level_and_notify(uint8_t level)
{
	return bt_bas_set_battery_level(level);
}