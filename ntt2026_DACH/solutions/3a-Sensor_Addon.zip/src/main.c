/*
 * Copyright (c) 2012-2014 Wind River Systems, Inc.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>

#include "bluetooth.h"

static const struct device *const i2c_bus = DEVICE_DT_GET(DT_NODELABEL(i2c22));
static const struct device *const itds = DEVICE_DT_GET(DT_NODELABEL(itds0));
static const struct device *const tids = DEVICE_DT_GET(DT_NODELABEL(tids0));
static const struct device *const veml7700 = DEVICE_DT_GET(DT_NODELABEL(veml7700));

/* Resolves to the DeviceTree node aliased as "die-temp0" in our overlay */
#define SENSOR_NODE DT_ALIAS(die_temp0)
//#define SENSOR_NODE DT_NODELABEL(simulated_sensor)
const struct device *const dev = DEVICE_DT_GET(SENSOR_NODE);

/*
 * Raw I2C address probe, independent of the WSEN-ITDS driver. This only
 * checks whether *something* ACKs the given 7-bit address on the bus - it
 * does not talk to any particular register - so it isolates wiring/soldering
 * problems (no ACK at all) from configuration problems (ACK, but the driver
 * still rejects the device, e.g. because of a WHO_AM_I mismatch).
 */
static void i2c_probe_addr(uint8_t addr, const char *name)
{
    uint8_t dummy;
    int ret = i2c_read(i2c_bus, &dummy, 1, addr);

    printk("I2C probe: 0x%02x (%s): %s (err %d)\n", addr, name,
    ret == 0 ? "ACK - device responded" : "NACK/no response", ret);
}

int main(void)
{
    struct sensor_value temp;
    struct sensor_value accel[3];
    struct sensor_value itds_temp;
    struct sensor_value tids_temp;
    int ret;

	printf("Hello World! %s\n", CONFIG_BOARD_TARGET);

    if (!device_is_ready(dev)) {
        printk("Sensor is not ready %s\n", dev->name);
        return 0;
    }
    printk("Sensor is ready!\n");

    if (!device_is_ready(i2c_bus)) {
        printk("Error: I2C bus device is not ready\n");
        return 0;
    }

    /*
     * SAO=GND should put the ITDS at 0x18. Also probe 0x19 (SAO=VDD) in
     * case the SAO pin isn't actually reaching GND (e.g. a cold solder
     * joint or open connection can leave it floating/high).
     */
    i2c_probe_addr(0x18, "ITDS, SAO=GND");
    //i2c_probe_addr(0x19, "ITDS, SAO=VDD");
    i2c_probe_addr(0x3f, "TIDS, SAO=GND");
    i2c_probe_addr(0x10, "VEML7700");

    if (!device_is_ready(itds)) {
        printk("Error: WSEN-ITDS device is not ready\n");
        return 0;
    }

    if (!device_is_ready(tids)) {
        printk("Error: WSEN-TIDS device is not ready\n");
        return 0;
    }

    if (!device_is_ready(veml7700)) {
        printk("Error: VEML7700 device is not ready\n");
        return 0;
    }

    int err = bluetooth_init();
    if (err) {
        printk("Bluetooth initialization failed (err %d)\n", err);
        return 0;
    }

    while (true) {
        // Fetch a sample from the sensor and store it in an internal driver buffer
        if (sensor_sample_fetch(dev) < 0) {
            printk("Error: Sensor sample update error\n");
            return 0;
        }

        // Get a reading from a sensor device (read temperature)
        if (sensor_channel_get(dev, SENSOR_CHAN_DIE_TEMP, &temp) < 0) {
            printk("Error: Cannot read temperature channel\n");
            return 0;
        }

        /* display temperature */
        printk("Temperature: %.1f C\n", sensor_value_to_double(&temp));


        /* Handling sensors from Sensor Add-on Board */
        /* --- Würth Elektronik WSEN-ITDS 3 Axis Acceleration Sensor ---*/
        ret = sensor_sample_fetch(itds);
        if (ret < 0) {
            printk("ITDS: failed to fetch sample (%d)\n", ret);
        } else {
            sensor_channel_get(itds, SENSOR_CHAN_ACCEL_XYZ, accel);
            sensor_channel_get(itds, SENSOR_CHAN_AMBIENT_TEMP, &itds_temp);

            printk("ITDS: accel x=%.3f y=%.3f z=%.3f [m/s^2], temp=%.2f C\n",
                   sensor_value_to_double(&accel[0]),
                   sensor_value_to_double(&accel[1]),
                   sensor_value_to_double(&accel[2]),
                   sensor_value_to_double(&itds_temp));
        }

        /* --- Würth Elektronik WSEN-TIDS Temperature Sensor --- */
        ret = sensor_sample_fetch(tids);
        if (ret < 0) {
            printk("TIDS: failed to fetch sample (%d)\n", ret);
        } else {
            sensor_channel_get(tids, SENSOR_CHAN_AMBIENT_TEMP, &tids_temp);
            printk("TIDS: temp=%d.%06d C\n", tids_temp.val1, tids_temp.val2);
        }

        /* --- Vishay VEML7700 ambient light sensor --- */
        ret = sensor_sample_fetch(veml7700);
        if (ret < 0) {
            printk("VEML7700: failed to fetch sample (%d)\n", ret);
        } else {
            struct sensor_value light;

            sensor_channel_get(veml7700, SENSOR_CHAN_LIGHT, &light);
            printk("VEML7700: light=%d.%06d lux\n", light.val1, light.val2);
        }

        k_sleep(K_MSEC(2000));
    }

	return 0;
}
