#ifndef BLE_NEW_BLUETOOTH_H_
#define BLE_NEW_BLUETOOTH_H_

#include <stdint.h>

int bluetooth_init(void);
int bluetooth_battery_level_update(uint8_t level);

#endif