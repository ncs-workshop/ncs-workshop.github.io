#include "bluetooth.h"

#include <errno.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/sys/util.h>

static const struct bt_data advertising_data[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA_BYTES(BT_DATA_UUID16_ALL, BT_UUID_16_ENCODE(BT_UUID_BAS_VAL)),
};

static const struct bt_data scan_response_data[] = {
	BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
		sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

static void advertising_work_handler(struct k_work *work)
{
	int err;

	ARG_UNUSED(work);

	err = bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, advertising_data,
			      ARRAY_SIZE(advertising_data), scan_response_data,
			      ARRAY_SIZE(scan_response_data));
	if (err == -EALREADY) {
		return;
	}
	if (err) {
		printk("Bluetooth advertising restart failed (err %d)\n", err);
		return;
	}

	printk("Bluetooth advertising restarted\n");
}

K_WORK_DEFINE(advertising_work, advertising_work_handler);

static void schedule_advertising_restart(void)
{
	int err = k_work_submit(&advertising_work);

	if (err < 0) {
		printk("Could not schedule advertising restart (err %d)\n", err);
	}
}

static void connected(struct bt_conn *conn, uint8_t err)
{
	ARG_UNUSED(conn);

	if (err) {
		printk("Bluetooth connection failed (err 0x%02x %s)\n", err,
		       bt_hci_err_to_str(err));
		schedule_advertising_restart();
		return;
	}

	printk("Bluetooth connected\n");
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	ARG_UNUSED(conn);

	printk("Bluetooth disconnected (reason 0x%02x %s)\n", reason,
	       bt_hci_err_to_str(reason));
	schedule_advertising_restart();
}

BT_CONN_CB_DEFINE(connection_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
};

int bluetooth_init(void)
{
	int err = bt_enable(NULL);

	if (err) {
		printk("Bluetooth initialization failed (err %d)\n", err);
		return err;
	}

	printk("Bluetooth initialized\n");

	err = bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, advertising_data,
			      ARRAY_SIZE(advertising_data), scan_response_data,
			      ARRAY_SIZE(scan_response_data));
	if (err) {
		printk("Bluetooth advertising failed to start (err %d)\n", err);
		return err;
	}

	printk("Bluetooth advertising started as %s\n", CONFIG_BT_DEVICE_NAME);
	return 0;
}

int bluetooth_battery_level_update(uint8_t level)
{
	if (level > 100U) {
		return -EINVAL;
	}

	return bt_bas_set_battery_level(level);
}