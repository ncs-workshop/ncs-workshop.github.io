/*
 * Copyright (c) 2012-2014 Wind River Systems, Inc.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/sensor.h>

#include "bluetooth.h"

    uint8_t battery_level = 100U;
    bool battery_depleted = false;
/* Resolves to the DeviceTree node aliased as "die-temp0" in our overlay */
#define SENSOR_NODE DT_ALIAS(die_temp0)
//#define SENSOR_NODE DT_NODELABEL(simulated_sensor)
const struct device *const dev = DEVICE_DT_GET(SENSOR_NODE);

int main(void)
{
    int err;

    printf("Hello World! %s\n", CONFIG_BOARD_TARGET);

    err = bluetooth_init();
    if (err) {
        printk("Bluetooth startup failed (err %d)\n", err);
        return err;
    }

    if (!device_is_ready(dev)) {
        printk("Sensor is not ready %s\n", dev->name);
        return 0;
    }
    printk("Sensor is ready!\n");

    struct sensor_value temp;

    while (true) {
        // Fetch a sample from the sensor and store it in an internal driver buffer
        if (sensor_sample_fetch(dev) < 0) {
            printk("Error: Sensor sample update error\n");
            return 0;
        }

        // Get a reading from a sensor device (read temperature)
        if (sensor_channel_get(dev, SENSOR_CHAN_DIE_TEMP, &temp) < 0) {
            printk("Error: Cannot read temperature channel\n");
            return 0;
        }

        /* display temperature */
        printk("Temperature: %.1f C\n", sensor_value_to_double(&temp));

        if (!battery_depleted) {
            err = bluetooth_battery_level_update(battery_level);
            if (err) {
                printk("Battery Level update failed (err %d)\n", err);
            }

            if (battery_level == 0U) {
                battery_depleted = true;
            } else {
                battery_level--;
            }
        }

        k_sleep(K_MSEC(2000));
    }

    return 0;
}
