#ifndef AT_HANDLER_H_
#define AT_HANDLER_H_

#include <stddef.h>
#include <zephyr/kernel.h>

/* Unsolicited response, e.g. "+CEREG: 1,\"1A2B\"" -> name "+CEREG", count 2, params "1,\"1A2B\"" */
struct at_urc {
	char name[16];
	int param_count;
	char params[96];
};

typedef void (*at_raw_cb_t)(const char *line);
typedef void (*at_urc_cb_t)(const struct at_urc *urc);

/* Called for every received line (CR/LF stripped) */
void at_set_raw_cb(at_raw_cb_t cb);
/* Called for every unsolicited response */
void at_set_urc_cb(at_urc_cb_t cb);

int at_init(void);
/* Wait for the modem to report "RDY". Returns 0 or -EAGAIN on timeout */
int at_wait_ready(k_timeout_t timeout);
/* Send one command. resp (optional) receives the response text without OK/ERROR,
 * lines joined with newline. 0 = OK, -1 = ERROR, >0 = +CME ERROR number, -ETIMEDOUT */
int at_cmd_send(const char *cmd, char *resp, size_t resp_size);
/* Queue one command and return immediately (safe from IRQ). The command is sent from
 * a separate thread and the result is logged. 0 = queued, -ENOMEM = queue full
 */
int at_cmd_send_async(const char *cmd);
/* Send an array of commands, stops at the first failure. Same return codes */
int at_cmds_send(const char *const *cmds, size_t count);

#endif
