#include <stdlib.h>
#include <string.h>
#include <zephyr/logging/log.h>
#include "modem.h"

LOG_MODULE_REGISTER(modem, LOG_LEVEL_INF);

static const char *const init_cmds[] = {
	"AT+CMEE=1",
	"AT+CGMR",
	"AT+CGMM",
	"AT+CFUN=0",
};

static const char *const connect_cmds[] = {
	"AT+CSCON=1",
	"AT+CEREG=5",
	"AT+CGEREP=1",
	"AT+CFUN=1",
};

static K_SEM_DEFINE(connected_sem, 0, 1);
static at_urc_cb_t app_urc_cb;

static void urc_handler(const struct at_urc *urc)
{
	LOG_INF("URC: %s: %s", urc->name, urc->params);

	if (strcmp(urc->name, "+CEREG") == 0) {
		int stat = atoi(urc->params);

		if (stat == 1 || stat == 5) {
			k_sem_give(&connected_sem);
		}
	}
	if (app_urc_cb) {
		app_urc_cb(urc);
	}
}

void modem_set_urc_cb(at_urc_cb_t cb)
{
	app_urc_cb = cb;
}

int modem_init(void)
{
	int err = at_init();

	if (err) {
		return err;
	}
	at_set_urc_cb(urc_handler);

	LOG_INF("Waiting for modem RDY");
	err = at_wait_ready(K_SECONDS(120));
	if (err) {
		return -ETIMEDOUT;
	}
	return at_cmds_send(init_cmds, ARRAY_SIZE(init_cmds));
}

int modem_connect(void)
{
	int err = at_cmds_send(connect_cmds, ARRAY_SIZE(connect_cmds));

	if (err) {
		return err;
	}
	LOG_INF("Waiting for network registration");
	return k_sem_take(&connected_sem, K_MINUTES(15));
}
