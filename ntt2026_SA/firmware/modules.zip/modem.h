#ifndef MODEM_H_
#define MODEM_H_

#include <stddef.h>
#include "ATHandler.h"

/* Wait for modem RDY and run the init AT commands */
int modem_init(void);
/* Register for network and wait for +CEREG: 1 or 5 */
int modem_connect(void);
/* Application URC callback (all URCs are also logged by the module) */
void modem_set_urc_cb(at_urc_cb_t cb);

#endif
