#include <stdlib.h>
#include <string.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/ring_buffer.h>
#include <zephyr/logging/log.h>
#include "ATHandler.h"

LOG_MODULE_REGISTER(at, LOG_LEVEL_INF);

#define MODEM_UART DEVICE_DT_GET(DT_NODELABEL(uart30))
#define CMD_TIMEOUT K_SECONDS(10)

RING_BUF_DECLARE(rx_rb, 512);

static void rx_work_fn(struct k_work *work);
static K_WORK_DEFINE(rx_work, rx_work_fn);
static K_SEM_DEFINE(rsp_sem, 0, 1);
static K_SEM_DEFINE(rdy_sem, 0, 1);
static K_MUTEX_DEFINE(cmd_mutex);

/* Async commands: queued from any context (e.g. IRQ), sent from their own thread
 * so the blocking wait for OK never stalls the RX parsing on the system work queue.
 */
#define ASYNC_CMD_MAX 160
K_MSGQ_DEFINE(async_q, ASYNC_CMD_MAX, 4, 1);
K_THREAD_STACK_DEFINE(async_stack, 1536);
static struct k_work_q async_wq;
static void async_work_fn(struct k_work *work);
static K_WORK_DEFINE(async_work, async_work_fn);

static at_raw_cb_t raw_cb;
static at_urc_cb_t urc_cb;
static int rsp_result;

/* State of the command in flight, used to collect its response text */
static const char *cur_cmd;
static char cur_prefix[16];
static char *rsp_buf;
static size_t rsp_size;
static size_t rsp_len;

static void rsp_append(const char *line)
{
	if (!rsp_buf || rsp_len + 1 >= rsp_size) {
		return;
	}
	if (rsp_len > 0) {
		rsp_buf[rsp_len++] = '\n';
	}
	size_t n = MIN(strlen(line), rsp_size - rsp_len - 1);

	memcpy(rsp_buf + rsp_len, line, n);
	rsp_len += n;
	rsp_buf[rsp_len] = '\0';
}

void at_set_raw_cb(at_raw_cb_t cb) { raw_cb = cb; }
void at_set_urc_cb(at_urc_cb_t cb) { urc_cb = cb; }

/* UART interrupt: only move bytes to the ring buffer, work queue does the rest */
static void uart_isr(const struct device *dev, void *user_data)
{
	uint8_t buf[32];

	uart_irq_update(dev);

	while (uart_irq_rx_ready(dev)) {
		int len = uart_fifo_read(dev, buf, sizeof(buf));

		if (len <= 0) {
			break;
		}
		ring_buf_put(&rx_rb, buf, len);
	}
	k_work_submit(&rx_work);
}

static void handle_line(char *line)
{
	if (raw_cb) {
		raw_cb(line);
	}

	if (strcmp(line, "OK") == 0) {
		rsp_result = 0;
		k_sem_give(&rsp_sem);
	} else if (strcmp(line, "ERROR") == 0) {
		rsp_result = -1;
		k_sem_give(&rsp_sem);
	} else if (strncmp(line, "+CME ERROR:", 11) == 0) {
		rsp_result = atoi(line + 11);
		k_sem_give(&rsp_sem);
	} else if (strcmp(line, "RDY") == 0) {
		k_sem_give(&rdy_sem);
	} else if (cur_cmd && strcmp(line, cur_cmd) == 0) {
		/* command echo, ignore */
	} else if (cur_cmd && (line[0] != '+' ||
		   (cur_prefix[0] && strncmp(line, cur_prefix, strlen(cur_prefix)) == 0))) {
		/* response data belonging to the command in flight */
		rsp_append(line);
	} else if (line[0] == '+') {
		struct at_urc urc = {0};
		char *sep = strchr(line, ':');

		if (sep) {
			*sep = '\0';
			sep++;
			while (*sep == ' ') {
				sep++;
			}
		}
		strncpy(urc.name, line, sizeof(urc.name) - 1);
		if (sep && *sep) {
			strncpy(urc.params, sep, sizeof(urc.params) - 1);
			urc.param_count = 1;
			for (char *p = urc.params; *p; p++) {
				if (*p == ',') {
					urc.param_count++;
				}
			}
		}
		if (urc_cb) {
			urc_cb(&urc);
		}
	}
}

static void rx_work_fn(struct k_work *work)
{
	static char line[256];
	static size_t len;
	uint8_t c;

	while (ring_buf_get(&rx_rb, &c, 1) == 1) {
		if (c == '\r' || c == '\n') {
			if (len > 0) {
				line[len] = '\0';
				len = 0;
				handle_line(line);
			}
		} else if (len < sizeof(line) - 1) {
			line[len++] = c;
		}
	}
}

int at_init(void)
{
	const struct device *uart = MODEM_UART;

	if (!device_is_ready(uart)) {
		return -ENODEV;
	}
	k_work_queue_start(&async_wq, async_stack, K_THREAD_STACK_SIZEOF(async_stack),
			   K_PRIO_PREEMPT(8), NULL);
	uart_irq_callback_user_data_set(uart, uart_isr, NULL);
	uart_irq_rx_enable(uart);
	return 0;
}

int at_wait_ready(k_timeout_t timeout)
{
	return k_sem_take(&rdy_sem, timeout);
}

int at_cmd_send(const char *cmd, char *resp, size_t resp_size)
{
	int err;

	k_mutex_lock(&cmd_mutex, K_FOREVER);

	/* prefix of the command, "AT+CGMR" -> "+CGMR" */
	const char *p = cmd + (strncmp(cmd, "AT", 2) == 0 ? 2 : 0);
	size_t n = strcspn(p, "=?");

	memset(cur_prefix, 0, sizeof(cur_prefix));
	if (p[0] == '+') {
		memcpy(cur_prefix, p, MIN(n, sizeof(cur_prefix) - 1));
	}

	/* No caller buffer: collect into a local one so the response can still be logged */
	static char log_buf[256];
	bool log_it = (resp == NULL);

	if (log_it) {
		resp = log_buf;
		resp_size = sizeof(log_buf);
	}
	rsp_buf = resp;
	rsp_size = resp_size;
	rsp_len = 0;
	resp[0] = '\0';
	k_sem_reset(&rsp_sem);
	cur_cmd = cmd;

	for (p = cmd; *p; p++) {
		uart_poll_out(MODEM_UART, *p);
	}
	uart_poll_out(MODEM_UART, '\r');

	if (k_sem_take(&rsp_sem, CMD_TIMEOUT) != 0) {
		err = -ETIMEDOUT;
	} else {
		err = rsp_result;
	}
	cur_cmd = NULL;

	if (log_it) {
		if (resp[0]) {
			LOG_INF("> %s = %s", cmd, resp);
		} else {
			LOG_INF("> %s", cmd);
		}
	}
	k_mutex_unlock(&cmd_mutex);
	return err;
}

static void async_work_fn(struct k_work *work)
{
	static char cmd[ASYNC_CMD_MAX];

	while (k_msgq_get(&async_q, cmd, K_NO_WAIT) == 0) {
		int err = at_cmd_send(cmd, NULL, 0);

		LOG_INF("%s -> %d", cmd, err);
	}
}

int at_cmd_send_async(const char *cmd)
{
	/* Callable from IRQ: copy into the queue and kick the sender thread */
	if (strlen(cmd) >= ASYNC_CMD_MAX) {
		return -EINVAL;
	}
	char item[ASYNC_CMD_MAX] = {0};

	strcpy(item, cmd);
	if (k_msgq_put(&async_q, item, K_NO_WAIT) != 0) {
		return -ENOMEM;
	}
	k_work_submit_to_queue(&async_wq, &async_work);
	return 0;
}

int at_cmds_send(const char *const *cmds, size_t count)
{
	for (size_t i = 0; i < count; i++) {
		int err = at_cmd_send(cmds[i], NULL, 0);

		if (err) {
			return err;
		}
	}
	return 0;
}
